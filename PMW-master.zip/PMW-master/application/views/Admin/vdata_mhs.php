			<div class="main-panel">
				<div class="content">
					<div class="container-fluid">
						<h4 class="page-title">Data Mahasiswa</h4>
							<div class="col-md-12">
								<div class="card">
															<div class="col-md-12">
								<div class="card card-tasks">
									
									<div class="card-body ">
										<div class="table-full-width">
											<table class="table">
												<thead>
													<tr>
														<th>Nama Mahasiswa</th>
														<th>Jurusan</th>
														<th>Program Studi</th>
														<th>NIM</th>
														<th>Email</th>
														<th>Jenis Kelamin</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td>Roy Achmad Aziz</td>
														<td>Teknologi Informasi</td>
														<td>D4 Teknik Informatika</td>
														<td>1641720099</td>
														<td>royachmad06@gmail.com</td>
														<td>Laki-laki</td>
														<td class="td-actions text-left">
															<div class="form-button-action">
																<button type="button" data-toggle="tooltip" title="Edit Task" class="btn btn-link <btn-simple-primary">
																	<i class="la la-edit"></i>
																</button>
																<button type="button" data-toggle="tooltip" title="Remove" class="btn btn-link btn-simple-danger">
																	<i class="la la-times"></i>
																</button>
															</div>
														</td>
													</tr>
													<tr>
														<td>Roy Achmad Aziz</td>
														<td>Teknologi Informasi</td>
														<td>D4 Teknik Informatika</td>
														<td>1641720099</td>
														<td>royachmad06@gmail.com</td>
														<td>Laki-laki</td>
														<td class="td-actions text-left">
															<div class="form-button-action">
																<button type="button" data-toggle="tooltip" title="Edit Task" class="btn btn-link <btn-simple-primary">
																	<i class="la la-edit"></i>
																</button>
																<button type="button" data-toggle="tooltip" title="Remove" class="btn btn-link btn-simple-danger">
																	<i class="la la-times"></i>
																</button>
															</div>
														</td>
													</tr>
													<tr>
														<td>Roy Achmad Aziz</td>
														<td>Teknologi Informasi</td>
														<td>D4 Teknik Informatika</td>
														<td>1641720099</td>
														<td>royachmad06@gmail.com</td>
														<td>Laki-laki</td>
														<td class="td-actions text-left">
															<div class="form-button-action">
																<button type="button" data-toggle="tooltip" title="Edit Task" class="btn btn-link <btn-simple-primary">
																	<i class="la la-edit"></i>
																</button>
																<button type="button" data-toggle="tooltip" title="Remove" class="btn btn-link btn-simple-danger">
																	<i class="la la-times"></i>
																</button>
															</div>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
										
									</div>
									<div class="card-footer ">
										<div class="stats">
											<a href="<?=site_url()?>/admin/tambah_mhs" class="btn btn-success" >Tambah Data</a>
										</div>
									</div>
								</div>
							</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="modalUpdate" tabindex="-1" role="dialog" aria-labelledby="modalUpdatePro" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header bg-primary">
					<h6 class="modal-title"><i class="la la-frown-o"></i> Under Development</h6>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body text-center">									
					<p>Currently the pro version of the <b>Ready Dashboard</b> Bootstrap is in progress development</p>
					<p>
						<b>We'll let you know when it's done</b></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>